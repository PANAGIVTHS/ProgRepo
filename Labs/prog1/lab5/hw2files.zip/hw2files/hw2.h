#ifndef _HW2_H_
#define _HW2_H_

#define MAX_WORDS 100
#define MAX_WORD_LEN 24
#define MAX_SYNONYMS 100
#define MAX_LINE_LEN 50
#define MAX_FILENAME_LEN 20

#endif

#include<string.h>
#include<stdio.h>
#include<ctype.h>
#include "hw2.h"

void lower(char *word) ;
int read_synonyms(char *filename, char synonyms[][MAX_WORD_LEN*2]) ;

/******
 main
******/
int main (int argc, char *argv[]) {

    return 0;
}

/****************************************
 Converts the given string to lowercase 
*****************************************/
void lower(char *word) {
    while (*word) {
        *word = tolower(*word);
        word++;
    }
}
    
/************************************************************
 Reads pairs of words and their synonyms from the given file
 and stores them in the table, one pair per line.
 The words of a pair are separated by a '\0'.

  Assumes the table has MAX_SYNONYMS rows.

  Returns 1 on success, 0 on failure.
*************************************************************/
int read_synonyms(char *filename, char synonyms[][MAX_WORD_LEN*2]) {
    int i;
    char word[MAX_WORD_LEN]={'\0'}, word_synonym[MAX_WORD_LEN]={'\0'};
    char format[30];
    FILE *fp;
  
    fp = fopen(filename, "r");
    if(!fp) {
        fprintf(stderr, "Error: Could not open file \"%s\" for reading\n", filename);
        return 0;
    }
  
    sprintf(format, "%%%ds", MAX_WORD_LEN-1);
    memset(synonyms, 0, MAX_SYNONYMS*MAX_WORD_LEN*2);  

    i=0;
    while(i < MAX_SYNONYMS && EOF != fscanf(fp, format, word)) {
        lower(word);
        strcpy(synonyms[i], word);
        if (EOF == fscanf(fp, format, word_synonym))  {   
            fclose(fp);
            fprintf(stderr, "Error: Missing synonym for word \"%s\"\n", word);
            return 0;
        }
        lower(word_synonym);
        strcpy(synonyms[i]+strlen(word)+1, word_synonym);
        i++;
    }
    fclose(fp);
    return 1;
}
